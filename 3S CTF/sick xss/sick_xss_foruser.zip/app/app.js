const express = require('express');
const cors = require('cors');
const BP = require('body-parser');
const puppeteer = require('puppeteer')
const cookieParser= require('cookie-parser');
const app = express();
const session = require('express-session');
const bodyParser = require('body-parser');
const qs = require('querystring');

app.set('view engine', 'ejs');
app.use(express.urlencoded({extended:true,}));
app.use(cookieParser());

app.use(session({
    secret: '##@#@#@#@##@#@#@##@',
    resave:false,
    saveUninitialized:true
}));

if(!process.argv[2]){
    console.log("ERROR");
    return -1;
}

const port = process.argv[2];
const bot_URL = 'http://127.0.0.1:'+port;

const bot = async (report, flag) => {


    const cookies=[
        {name: "flag", value: flag, domain: "127.0.0.1:"+port}
    ]

    const browser = await puppeteer.launch({
        headless: true,
        //executablePath: "/usr/bin/google-chrome-stable",
        args: ["--no-sandbox"],
      });
    
    const page = await browser.newPage();
    await page.setCookie(...cookies);

    await page.goto(bot_URL+'/echo');
    await setTimeout(()=>{},300);

    await page.waitForSelector("#echo");
    await page.evaluate((re)=>{
        document.querySelector("#echo").value=re;
    },report);

    await page.waitForSelector("#submit");
    await page.click("#submit");
    await setTimeout(()=>{},100);

    await page.waitForNavigation();
    await page.close();
    await browser.close();

}


var db = [
    {'row':0, 'id': 'admin','title':'TEST','contents':'test'}

]

app.get('/', (req, res) =>{
    
    res.render('index')
})

app.post('/echo', (req,res)=>{
    const filter_string = /\s|document|cookie|alert|on|script|`|{|=|;|<|>/i;
    const more_string = /^[a-z]{4,}$/;

    if(req.body.echo){
     if(req.body.echo.match(filter_string) != null || req.body.echo.match(more_string)){
        res.send('Filtered');
        return 0;
        }
        res.send("<script>"+req.body.echo+"</script>");
    }
    else
        res.send('?echo=input_echo_string')
})

app.get('/echo',(req,res)=>{
    res.render('echo');
})


app.post('/bot', (req,res)=>{
    if(!req.body.report){
        res.render('bot');
        return 0;
    }

    bot(req.body.report,'3S{**REDACTED**]').then(()=>{
        res.send("<script>alert('GOOD!');history.back();</script>");
    }).catch((e)=>{
        console.log(e)
        res.send("<script>alert('NOPE!');history.back();</script>");
    })
    
})
app.get('/bot',(req,res)=>{
    res.render('bot');
})


app.listen(port, ()=>{
    console.log("Server started:"+port)
})